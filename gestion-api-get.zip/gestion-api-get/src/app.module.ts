import { Module } from '@nestjs/common';
import { createObserveModule } from '@nestjs/observe';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { InicioController } from './inicio.controller';

export const { ObserveModule, ObserveInstrument } = createObserveModule();

@Module({
  imports: [],
    
  controllers: [AppController,InicioController ],
  providers: [AppService],
})
export class AppModule {}
